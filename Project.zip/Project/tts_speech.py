from gtts import gTTS
import os

def text_to_speech(text, language='en'):
    # Create a gTTS object
    tts = gTTS(text=text, lang=language)
 
    # Save the audio to a file
    tts.save("text.mp3")
    os.system("mpg123 text.mp3")

text_to_speech("Activating text recognition.")
