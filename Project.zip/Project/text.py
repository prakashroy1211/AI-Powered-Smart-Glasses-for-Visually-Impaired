from gtts import gTTS
import os
import requests
import pygame

def play_music(file):
    # Initialize Pygame mixer
    pygame.mixer.init()
    try:
        # Load the MP3 file
        pygame.mixer.music.load(file)
        # Play the loaded MP3 file
        pygame.mixer.music.play()
        # Wait for playback to finish
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)
    except pygame.error as e:
        print("Cannot play file: ", e)

def text_to_speech(text, language='en'):
    # Create a gTTS object
    tts = gTTS(text=text, lang=language)

    # Save the audio to a file
    tts.save("speech.mp3")
    play_music("speech.mp3")

text = "hello world"
text_to_speech(text)



