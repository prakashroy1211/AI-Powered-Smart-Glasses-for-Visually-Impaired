import cv2
import numpy as np
import json
import os
from stereovision.calibration import StereoCalibration
from start_cameras import Start_Cameras

duration = 3  # seconds
freq = 1000  # Hz

# Depth map default preset
SWS = 5
PFS = 5
PFC = 29
MDS = -30
NOD = 160
TTH = 100
UR = 10
SR = 14
SPWS = 100



def load_map_settings(file):
    global SWS, PFS, PFC, MDS, NOD, TTH, UR, SR, SPWS, sbm
    print('Loading parameters from file...')
    with open(file, 'r') as f:
        data = json.load(f)
        # loading data from the json file and assigning it to the Variables
        SWS = data['SADWindowSize']
        PFS = data['preFilterSize']
        PFC = data['preFilterCap']
        MDS = data['minDisparity']
        NOD = data['numberOfDisparities']
        TTH = data['textureThreshold']
        UR = data['uniquenessRatio']
        SR = data['speckleRange']
        SPWS = data['speckleWindowSize']
    
    # changing the actual values of the variables
    sbm = cv2.StereoBM_create(numDisparities=16, blockSize=SWS) 
    sbm.setPreFilterCap(PFC)
    sbm.setMinDisparity(MDS)
    sbm.setNumDisparities(NOD)
    sbm.setUniquenessRatio(UR)
    sbm.setSpeckleRange(SR)
    sbm.setSpeckleWindowSize(SPWS)
    print('Parameters loaded from file ' + file)

def stereo_depth_map(rectified_pair):
    dmLeft = rectified_pair[0]
    dmRight = rectified_pair[1]
    disparity = sbm.compute(dmLeft, dmRight)
    disparity_normalized = cv2.normalize(disparity, None, 0, 255, cv2.NORM_MINMAX)

    for y in range(disparity_normalized.shape[0]):
        for x in range(disparity_normalized.shape[1]):
            distance = disparity_normalized[y][x]
            if 40 < distance < 50:  # Exclude noise values
                print("Distance at pixel ({}, {}): {:.2f} cm".format(x, y, distance))
                os.system('play -nq -t alsa synth {} sine {}'.format(duration, freq))
                return True  # Signal to stop the program

    return False  # No distance in range found

if __name__ == "__main__":
    os.system("mpg123 navigation.mp3")
    left_camera = Start_Cameras(0).start()
    right_camera = Start_Cameras(1).start()
    load_map_settings("3dmap_set.txt")

    while True:
        left_grabbed, left_frame = left_camera.read()
        right_grabbed, right_frame = right_camera.read()

        if left_grabbed and right_grabbed:  
            left_gray_frame = cv2.cvtColor(left_frame, cv2.COLOR_BGR2GRAY)
            right_gray_frame = cv2.cvtColor(right_frame, cv2.COLOR_BGR2GRAY)

            calibration = StereoCalibration(input_folder='calib_result')
            rectified_pair = calibration.rectify((left_gray_frame, right_gray_frame))
            if stereo_depth_map(rectified_pair):
                break  # Exit the loop if distance in range found

    left_camera.stop()
    left_camera.release()
    right_camera.stop()
    right_camera.release()

