import cv2
import subprocess
import speech_recognition as sr
import os
from gtts import gTTS
import time

duration = 1  # seconds
freq = 440  # Hz

recognizer = sr.Recognizer()
def text_to_speech(text, language='en'):
    # Create a gTTS object
    tts = gTTS(text=text, lang=language)
 
    # Save the audio to a file
    tts.save("speech.mp3")
    os.system("mpg123 speech.mp3")

class ImageCapture:
    def __init__(self):
        self.sensor_id = 0  # Change this to your sensor ID

    def gstreamer_pipeline(self,
                           sensor_mode=3,
                           capture_width=1280,
                           capture_height=720,
                           display_width=640,
                           display_height=360,
                           framerate=30,
                           flip_method=0,
                           ):
        return (
                "nvarguscamerasrc sensor-id=%d sensor-mode=%d ! "
                "video/x-raw(memory:NVMM), "
                "width=(int)%d, height=(int)%d, "
                "format=(string)NV12, framerate=(fraction)%d/1 ! "
                "nvvidconv flip-method=%d ! "
                "video/x-raw, width=(int)%d, height=(int)%d, format=(string)BGRx ! "
                "videoconvert ! "
                "video/x-raw, format=(string)BGR ! appsink"
                % (
                    self.sensor_id,
                    sensor_mode,
                    capture_width,
                    capture_height,
                    framerate,
                    flip_method,
                    display_width,
                    display_height,
                )
        )

    def capture_and_save_image(self, image_path):
        # Create VideoCapture object
        cap = cv2.VideoCapture(self.gstreamer_pipeline(), cv2.CAP_GSTREAMER)
        
        if not cap.isOpened():
            text_to_speech("Error: Unable to open camera.")
            return
        
        # Capture frame-by-frame
        ret, frame = cap.read()
        
        if not ret:
            text_to_speech("Error: Unable to capture frame.")
            cap.release()
            return
        
        cv2.imwrite(image_path, frame)
        cap.release()
image_capture = ImageCapture()

def activate_text_recognition(image_path):
    image_capture.capture_and_save_image(image_path)
    cmd = "/home/prakash/miniforge3/condabin/conda run -n project python /home/prakash/Desktop/Project/tesseract.py"
    subprocess.call(cmd, shell=True)

def activate_object_recognition(image_path):
    image_capture.capture_and_save_image(image_path)
    cmd = "/home/prakash/miniforge3/condabin/conda run -n project python /home/prakash/Desktop/Project/blip.py"
    subprocess.call(cmd, shell=True)

def activate_navigation():
    cmd = "python /home/prakash/Desktop/Project/test.py"
    subprocess.call(cmd, shell = True)

def listen_for_commands():
    image_path="captured_image.jpg"
    while True:  # Continuous listening loop
        with sr.Microphone() as source:
            os.system('play -nq -t alsa synth {} sine {}'.format(duration, freq))
            audio = recognizer.record(source, 5)

        try:
            # Recognize speech using Google Speech Recognition
            command = recognizer.recognize_google(audio).lower()
            #print(command)
            #os.system("mpg123 commandrecognized.mp3")
            #time.sleep(1)

            # Check the recognized command and activate corresponding models
            if "what is in front of me" in command:
                activate_object_recognition(image_path)
                time.sleep(1)
            elif "read the text" in command:
                activate_text_recognition(image_path)
                time.sleep(1)
            elif "navigate me" in command:
                activate_navigation()
                time.sleep(2)
            elif "stop" in command:
                os.system('mpg123 stoppedlistening.mp3')
                time.sleep(4)
                subprocess.call("sudo /sbin/shutdown -h now", shell=True)
                break  # Exit the loop
            else:
                os.system("mpg123 unknowncommand.mp3")
                time.sleep(1)

        except sr.UnknownValueError:
            os.system("mpg123 couldnotunderstand.mp3")
        except sr.RequestError as e:
            text_to_speech("Could not request results from Google Speech Recognition service; {0}".format(e))

# Start listening for commands
listen_for_commands()


