import cv2
import pygame
import pytesseract
from gtts import gTTS
import os
import numpy as np

def play_music(file):
    # Initialize Pygame mixer
    pygame.mixer.init()
    try:
        # Load the MP3 file
        pygame.mixer.music.load(file)
        # Play the loaded MP3 file
        pygame.mixer.music.play()
        # Wait for playback to finish
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)
    except pygame.error as e:
        text_to_speech("Cannot play file: ", e)

def text_to_speech(text, language='en'):
    # Create a gTTS object
    tts = gTTS(text=text, lang=language)

    # Save the audio to a file
    tts.save("speech_tesseract.mp3")
    play_music("speech_tesseract.mp3")
def activate_text_recognition():
    text_to_speech("Activating text recognition...")
    pytesseract.pytesseract.tesseract_cmd = '/home/prakash/miniforge3/envs/project/bin/tesseract'
    config='digits'

    def perform_text_recognition(image_path):
    	img = cv2.imread(image_path)

    	if img is None:
        	print("Error: Image not found.")
        	return "Error: Image not found."

    # Convert to grayscale
    	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Apply adaptive thresholding to enhance text
    	processed_img = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 2)

    # Optional: Apply morphological transformations to remove noise
    	kernel = np.ones((1, 1), np.uint8)
    	processed_img = cv2.morphologyEx(processed_img, cv2.MORPH_CLOSE, kernel)

    # Save and debug the processed image
    	cv2.imwrite("processed_image.jpg", processed_img)

    # Perform OCR
    	text = pytesseract.image_to_string(processed_img, config='--psm 6')

    	return text.strip() if text.strip() else "No text detected."

    captured_image_path = "captured_image.jpg"
    recognized_text = perform_text_recognition(captured_image_path)
    text_to_speech(recognized_text)

activate_text_recognition()
