from gtts import gTTS
import pygame
import os
import requests
from PIL import Image
from transformers import BlipProcessor, BlipForConditionalGeneration
def play_music(file):
    # Initialize Pygame mixer
    pygame.mixer.init()
    try:
        # Load the MP3 file
        pygame.mixer.music.load(file)
        # Play the loaded MP3 file
        pygame.mixer.music.play()
        # Wait for playback to finish
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)
    except pygame.error as e:
        text_to_speech("Cannot play file: ", e)


def text_to_speech(text, language='en'):
    # Create a gTTS object
    tts = gTTS(text=text, lang=language)

    # Save the audio to a file
    tts.save("speech_blip.mp3")
    play_music("speech_blip.mp3")

def activate_object_recognition():
    text_to_speech("Activating object recognition...")
    processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-large")
    model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-large")

# Provide the file path of the image
    image_path = "captured_image.jpg"  # Replace this with the actual file path

# Open the image using PIL
    raw_image = Image.open(image_path).convert('RGB')

# unconditional image captioning
    inputs = processor(raw_image, return_tensors="pt")

    out = model.generate(**inputs)
    caption = processor.decode(out[0], skip_special_tokens=True)   
    text_to_speech(caption)
activate_object_recognition()
