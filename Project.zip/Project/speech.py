import speech_recognition as sr
recognizer = sr.Recognizer()

def listen_for_commands():
    while True:  # Continuous listening loop
        with sr.Microphone() as source:
            print("Listening for commands...")
            audio = recognizer.record(source,5)

        try:
            # Recognize speech using Google Speech Recognition
            command = recognizer.recognize_google(audio).lower()
            print("Command recognized:", command)

            # Check the recognized command and activate corresponding models
            if "what is in front of me" in command:
                activate_object_recognition()
            elif "read the text" in command:
                activate_text_recognition(conda_env_name)
            elif "stop" in command:  # Add a stop command to exit the loop
                print("Stopped Listening!!")
                break  # Exit the loop
            else:
                print("Unknown command. Please try again.")

        except sr.UnknownValueError:
            print("Google Speech Recognition could not understand audio.")
        except sr.RequestError as e:
            print("Could not request results from Google Speech Recognition service; {0}".format(e))

listen_for_commands()
