import cv2
import pygame
import pytesseract
from gtts import gTTS
import os
def play_music(file):
    # Initialize Pygame mixer
    pygame.mixer.init()
    try:
        # Load the MP3 file
        pygame.mixer.music.load(file)
        # Play the loaded MP3 file
        pygame.mixer.music.play()
        # Wait for playback to finish
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)
    except pygame.error as e:
        text_to_speech("Cannot play file: ", e)

def text_to_speech(text, language='en'):
    # Create a gTTS object
    tts = gTTS(text=text, lang=language)

    # Save the audio to a file
    tts.save("speech_tesseract.mp3")
    play_music("speech_tesseract.mp3")
def activate_text_recognition():
    text_to_speech("Activating text recognition...")
    pytesseract.pytesseract.tesseract_cmd = '/home/prakash/miniforge3/envs/project/bin/tesseract'
    config='digits'

    def perform_text_recognition(image_path):
    # Load the image using OpenCV
        img = cv2.imread(image_path)

    # Perform text recognition using Tesseract OCR
        text = pytesseract.image_to_string(img)

        return text

    captured_image_path = "captured_image.jpg"
    recognized_text = perform_text_recognition(captured_image_path)
    text_to_speech(recognized_text)

activate_text_recognition()
