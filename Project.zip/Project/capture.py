import cv2

class ImageCapture:
    def __init__(self):
        self.sensor_id = 0

    def gstreamer_pipeline(self,
                           sensor_mode=3,
                           capture_width=1280,
                           capture_height=720,
                           display_width=640,
                           display_height=360,
                           framerate=20,
                           flip_method=0,
                           ):
        return (
                "nvarguscamerasrc sensor-id=%d sensor-mode=%d ! "
                "video/x-raw(memory:NVMM), "
                "width=(int)%d, height=(int)%d, "
                "format=(string)NV12, framerate=(fraction)%d/1 ! "
                "nvvidconv flip-method=%d ! "
                "video/x-raw, width=(int)%d, height=(int)%d, format=(string)BGRx ! "
                "videoconvert ! "
                "video/x-raw, format=(string)BGR ! appsink"
                % (
                    self.sensor_id,
                    sensor_mode,
                    capture_width,
                    capture_height,
                    framerate,
                    flip_method,
                    display_width,
                    display_height,
                )
        )

    def capture_and_save_image(self, image_path):
        cap = cv2.VideoCapture(self.gstreamer_pipeline(), cv2.CAP_GSTREAMER)
        
        if not cap.isOpened():
            print("Error: Unable to open camera.")
            return
        
        # Capture frame-by-frame
        ret, frame = cap.read()
        
        if not ret:
            print("Error: Unable to capture frame.")
            cap.release()
            return
        
        # Save the captured frame as an image
        cv2.imwrite(image_path, frame)
        print("Image saved successfully at:", image_path)
        
        # Release the VideoCapture object
        cap.release()

# Example usage
image_capture = ImageCapture()
image_capture.capture_and_save_image("captured_image.jpg")

